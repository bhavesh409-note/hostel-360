#!/usr/bin/env bash
# Usage: gh auth login && bash create-issues.sh
# Creates labels and starter issues in bhavesh409-note/hostel-hub
R="bhavesh409-note/hostel-hub"
gh label create "good first issue" -R $R --color 7057ff 2>/dev/null
gh label create backend -R $R --color 0e8a16 2>/dev/null
gh label create frontend -R $R --color 1d76db 2>/dev/null
gh label create ai -R $R --color fbca04 2>/dev/null
gh label create iot -R $R --color d93f0b 2>/dev/null
gh label create security -R $R --color b60205 2>/dev/null
i(){ gh issue create -R $R --title "$1" --label "$2" --body "$3"; }
i "Add Supabase SQL schema and migrations" "backend" "Create tables from the spec (profiles, channels, posts, complaints, credit_transactions, etc.) with PKs, FKs, indexes and timestamps."
i "Row-level security policies" "backend,security" "Write RLS so students only read their own complaints, and Shield reports are visible only to wardens/admins."
i "Migrate UI to Next.js + TypeScript + Tailwind + shadcn/ui" "frontend" "Port index.html module by module. Keep the dark design tokens (#0B0D12, #121620, #171C27, violet and cyan accents)."
i "Supabase Auth: email/password, reset, verification" "backend" "Replace demo role switcher with real login and server-side role checks."
i "Gemini API route for complaint classification" "ai,backend" "Server-side endpoint only. Never expose the API key. Suggestions must be reviewable by a human."
i "Gemini hostel assistant with authorised context" "ai" "Answer from announcements, rules and channels. Must never read Shield reports."
i "ESP32 TDS sensor ingestion endpoint" "iot,backend" "POST /api/sensor/tds with device key auth, validation and rate limiting. Keep simulation mode clearly labelled."
i "Automatic 24h reminder and 48h escalation job" "backend" "Scheduled job for overdue complaints. Prevent duplicate penalties per ticket."
i "Scheduled announcements and expiry" "frontend,backend" "Support publish-at and expiry-at fields plus read receipts."
i "Profile pictures and file uploads via Supabase Storage" "backend,security" "Validate type and size server-side."
i "Add dark/light theme polish and mobile bottom navigation" "frontend,good first issue" "Improve small-screen layout of the sidebar."
i "Add keyboard shortcuts help dialog" "frontend,good first issue" "Show Ctrl+K and other shortcuts in a modal."
i "Monthly staff performance report export (CSV)" "frontend,good first issue" "Export credit history and resolution stats."
i "3D Digital Hostel Twin (three.js)" "frontend" "Add an optional 3D view on top of the 2D floor map."
echo done
